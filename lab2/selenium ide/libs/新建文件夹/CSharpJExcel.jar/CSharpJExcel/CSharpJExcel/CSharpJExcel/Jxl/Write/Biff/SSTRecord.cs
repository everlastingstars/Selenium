/*********************************************************************
*
*      Copyright (C) 2002 Andrew Khan
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
***************************************************************************/

// Port to C# 
// Chris Laforet
// Wachovia, a Wells-Fargo Company
// Feb 2010


using CSharpJExcel.Jxl.Biff;
using System.Collections;


namespace CSharpJExcel.Jxl.Write.Biff
	{
	/**
	 * A shared string table record. 
	 */
	class SSTRecord : WritableRecordData
		{
		/**
		 * The number of string references in the workbook
		 */
		private int numReferences;
		/**
		 * The number of strings in this table
		 */
		private int numStrings;
		/**
		 * The list of strings
		 */
		private ArrayList strings;
		/**
		 * The list of string lengths
		 */
		private ArrayList stringLengths;
		/**
		 * The binary data
		 */
		private byte[] data;
		/**
		 * The count of bytes needed so far to contain this record
		 */
		private int byteCount;

		/**
		 * The maximum amount of bytes available for the SST record
		 */
		private static int maxBytes = 8228 - // max length
									  8 - // bytes for string count fields
									  4; // standard biff record header

		/**
		 * Constructor
		 *
		 * @param numRefs the number of string references in the workbook
		 * @param s the number of strings
		 */
		public SSTRecord(int numRefs, int s)
			: base(Type.SST)
			{
			numReferences = numRefs;
			numStrings = s;
			byteCount = 0;
			strings = new ArrayList(50);
			stringLengths = new ArrayList(50);
			}

		/**
		 * Adds a string to this SST record.  It returns the number of string
		 * characters not added, due to space constraints.  In the event
		 * of this being non-zero, a continue record will be needed
		 *
		 * @param s the string to add
		 * @return the number of characters not added
		 */
		public int add(string s)
			{
			int bytes = s.Length * 2 + 3;

			// Must be able to add at least the first character of the string
			// onto the SST
			if (byteCount >= maxBytes - 5)
				{
				return s.Length > 0 ? s.Length : -1; // need to return some non-zero
				// value in order to force the creation of a continue record
				}

			stringLengths.Add((s.Length));

			if (bytes + byteCount < maxBytes)
				{
				// add the string and return
				strings.Add(s);
				byteCount += bytes;
				return 0;
				}

			// Calculate the number of characters we can add
			int bytesLeft = maxBytes - 3 - byteCount;
			int charsAvailable = bytesLeft % 2 == 0 ? bytesLeft / 2 :
													 (bytesLeft - 1) / 2;

			// Add what strings we can
			strings.Add(s.Substring(0, charsAvailable));
			byteCount += charsAvailable * 2 + 3;

			return s.Length - charsAvailable;
			}

		/**
		 * Gets the current offset into this record, excluding the header fields
		 *
		 * @return the number of bytes after the header field
		 */
		public int getOffset()
			{
			return byteCount + 8;
			}

		/**
		 * Gets the binary data for output to file
		 * 
		 * @return the binary data
		 */
		public override byte[] getData()
			{
			data = new byte[byteCount + 8];
			IntegerHelper.getFourBytes(numReferences, data, 0);
			IntegerHelper.getFourBytes(numStrings, data, 4);

			int pos = 8;
			int count = 0;

			int length = 0;
			foreach (string s in strings)
				{
				length = (int)stringLengths[count];
				IntegerHelper.getTwoBytes(length, data, pos);
				data[pos + 2] = 0x01;
				StringHelper.getUnicodeBytes(s, data, pos + 3);
				pos += s.Length * 2 + 3;
				count++;
				}

			return data;
			}
		}
	}

