
// Port to C# 
// Chris Laforet
// Wachovia, a Wells-Fargo Company
// Feb 2010

using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpJExcel.Jxl.Common
	{
	public class Logger
		{
		}
	}
